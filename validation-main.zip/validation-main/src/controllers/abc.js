function abc() {
    const a = "sdkhfk";
    function ab() {
        if (a != 1) {
            throw new Error("fkhdsklds")
        }
    }
    ab()
}

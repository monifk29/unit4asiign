const mongoose = require("mongoose");

// step 1 :- connect to mongodb
const connect = () => {
  return mongoose.connect(
    "mongodb+srv://Ritu1011:Atlas123@cluster0.pl4vh.mongodb.net/web_15?retryWrites=true&w=majority"
    );
};

module.exports = connect;
